using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Car : MonoBehaviour
{
    public Rigidbody2D Rb;
    public float _speed =10f;
   
    
    private void Awake()
    {
        Rb = GetComponent<Rigidbody2D>(); 
    }
    private void FixedUpdate()
    {
        Vector2 forward = new(transform.right.x, transform.right.y);
        Rb.MovePosition(Rb.position + _speed * Time.fixedDeltaTime * forward);
    }
}

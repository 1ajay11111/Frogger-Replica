using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shooting : MonoBehaviour
{
    public Transform firePoint; // The point from which the bullet is spawned
    public GameObject _bulletprefab; // The bullet GameObject
    public float _bulletSpeed = 10f; // Speed of the bullet
    public LayerMask targetLayer; // Layer mask to filter which objects can be hit by the raycast

    void Update()
    {
        if (Input.GetMouseButtonDown(0)) 
        {
            Shoot();
        }
    }

    void Shoot()
    {
        // Create a ray from the firePoint in the direction of the player's forward vector
        Ray2D ray = new(firePoint.position, firePoint.right);

        // Perform the raycast
        RaycastHit2D hit = Physics2D.Raycast(ray.origin, ray.direction, Mathf.Infinity, targetLayer);

        // Check if the raycast hit something
        if (hit.collider != null)
        {
            // If it hit something, spawn a Bullet at the hit point
            GameObject Bullet = Instantiate(_bulletprefab, firePoint.position, Quaternion.identity);

            // Calculate the direction to the hit point
            Vector2 direction = (hit.point - (Vector2)firePoint.position).normalized;

            // Set the velocity of the Bullet based on the direction and speed
            if (Bullet.TryGetComponent<Rigidbody2D>(out var rb))
            {
                rb.velocity = direction * _bulletSpeed;
            }
        }
        else
        {
            // If the raycast didn't hit anything, just spawn a Bullet in the default direction
            GameObject Bullet = Instantiate(_bulletprefab, firePoint.position, Quaternion.identity);
            if (Bullet.TryGetComponent<Rigidbody2D>(out var rb))
            {
                rb.velocity = firePoint.right * _bulletSpeed;
            }
        }
    }
}

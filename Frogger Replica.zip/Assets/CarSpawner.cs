using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CarSpawner : MonoBehaviour
{
    public GameObject CarPrefab;
    public float _spawnDelay = 0.3f;
    public Transform[] SpawnPoints;
    [SerializeField] private float _timer = 0f;


    private void Update()
    {
        if(_timer < _spawnDelay)
         _timer += Time.deltaTime; 
        else
        {
            SpawnCar();
            _timer = 0f;
        }
    }
    void SpawnCar()
    {
        int index = Random.Range(0, SpawnPoints.Length);
        Transform Spawnpoints = SpawnPoints[index];
        Instantiate(CarPrefab, Spawnpoints.position, Spawnpoints.rotation);
    }

}



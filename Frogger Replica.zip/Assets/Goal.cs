using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Goal : MonoBehaviour
{
    private void OnTriggerEnter2D(Collider2D collision)
    {
        Score.currentScore += 100;
        Debug.Log("You Won");
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);   
    }
}
